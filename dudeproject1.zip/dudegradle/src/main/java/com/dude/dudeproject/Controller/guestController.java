package com.dude.dudeproject.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class guestController {
}
