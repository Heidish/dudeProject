package com.dude.dudeproject.Service;

import com.dude.dudeproject.Repository.serviceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class serviceDaoService {

    @Autowired
    private serviceRepository repository;

    public serviceDaoService(serviceRepository repository) {
        this.repository = repository;
    }


    public String saveQR(String target_qr_no){

       return repository.saveQR(target_qr_no);
    }

    public String  qrCheck (String user_no){
        return repository. qrCheck(user_no);
    }



}
