package com.dude.dudeproject.Domain;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import java.sql.Blob;

@Data
@Entity
@Table(name = "service_tbl")
public class service {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "user_no")
    private Long user_no;

    @Column(name = "target_qr_no")
    private String target_qr_no;

    @Column(name = "qr_image")
    private Blob qr_image;


    @Builder
    public service(String target_qr_no) {
        this.target_qr_no = target_qr_no;
    }

    public service toEntity() {
        service s = service.builder().target_qr_no(target_qr_no).build();

        return s;
    }
}
