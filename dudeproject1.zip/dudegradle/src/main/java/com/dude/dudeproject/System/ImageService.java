package com.dude.dudeproject.System;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

@Service
public class ImageService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImageService.class);
    private static RandomClass r = new RandomClass();
    static String random;

    public String generateQRCode() {


        // 주소, 너비, 높이, 난수지정, bytearray -> byte[] 변환
        int width = 350;
        int height = 350;
        String text = "http://localhost:8090/";

        //랜덤값 추출
        random = r.numrandom(10);


        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        String url = text + random;
        BitMatrix matrix = null;
        try {
            matrix = new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, width, height);
            MatrixToImageWriter.writeToStream(matrix, MediaType.IMAGE_PNG.getSubtype(), baos);
        } catch (WriterException | IOException e) {
            e.printStackTrace();
        }


//        byte[] array = baos.toByteArray();

        System.out.println("url : " + url);
//        System.out.println("array : " + array);
        System.out.println("랜덤값 : " + random);


        return random;


    }


}
