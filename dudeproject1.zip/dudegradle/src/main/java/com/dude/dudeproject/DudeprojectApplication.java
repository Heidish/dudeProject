package com.dude.dudeproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DudeprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DudeprojectApplication.class, args);

	}

}
