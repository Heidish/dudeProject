package com.dude.dudeproject.Controller;

import com.dude.dudeproject.Service.serviceDaoService;
import com.dude.dudeproject.System.ImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/qr")
public class serviceController {

    @Autowired
    private serviceDaoService servicedao;

    @GetMapping(value = "/qrcode", produces = MediaType.IMAGE_PNG_VALUE)

    public String getQRCode(String target_qr_no) {
        // qr 코드에 있는 난수 가져와서~
        // TARGET_QR_NO 에 저장시켜주자.
        ImageService imageService = new ImageService();


        //2. 난수를 service_tbl 의 target_qr_no 에 저장

        target_qr_no = imageService.generateQRCode();


        servicedao.saveQR(target_qr_no);

        System.out.println("서비스 컨트롤러에서 난수 : " + target_qr_no);


        return "signup/login";

    }

    @GetMapping(value = "/qrCheck")
    public @ResponseBody String qrCheck(@RequestParam("user_no") String user_no) throws Exception {

        // 1. service_tbl의 user_no 로 target_qr_no 조회
        // 2. if-> user_no가 존재하지 않으면, user_info_tbl에 삽입되지 않은 값
        // 3. else -> user_info_tbl에 존재하므로, myaccount에  target_qr_no 띄워주기


        String check = servicedao.qrCheck(user_no);

        System.out.println("보내진 값 머야?: " + check);
        if (check == null) {`
            throw new Exception();
        }
        return "afterLogin/myAccount";
    }


    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
        return ResponseEntity.status(500).contentType(MediaType.TEXT_PLAIN).body(ex.getMessage());
    }


}
