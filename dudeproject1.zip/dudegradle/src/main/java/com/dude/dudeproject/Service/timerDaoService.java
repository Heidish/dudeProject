package com.dude.dudeproject.Service;

import org.springframework.stereotype.Service;

@Service
public class timerDaoService {
}
