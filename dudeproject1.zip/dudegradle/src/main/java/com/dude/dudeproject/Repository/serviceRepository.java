package com.dude.dudeproject.Repository;

import com.dude.dudeproject.Domain.service;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface serviceRepository extends JpaRepository<service, Long> {


    @Query(value= "insert into service_tbl (user_no, target_qr_no) values (3, :target_qr_no)", nativeQuery = true)
     String saveQR (@Param("target_qr_no") String target_qr_no);

    @Query(value = "select target_qr_no from service where user_no=3")
    String qrCheck(@Param("user_no") String user_no);


}
