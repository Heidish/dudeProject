package com.dude.dudeproject.oauth;

public class clientResources {

}
