package com.dude.dudeproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DudeprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
